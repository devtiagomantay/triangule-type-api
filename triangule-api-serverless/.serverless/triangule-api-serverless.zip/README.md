 ## DEV ##
 
Requirements:

* NodeJS
* JDK
> sudo apt install default-jdk
* AWS CLI
* serverless-python-requirements
> sls plugin install -n serverless-python-requirements

* To manage the requirements.txt file
> pip install pipreqs



