import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='devtiagomantay',
    application_name='triangule-api-serverless',
    app_uid='4kcRQH4qvvkvnJXWWJ',
    org_uid='c0cd7727-670a-4ae9-b8cb-4751daf7b366',
    deployment_uid='00477ea0-d488-49b5-b743-b3fb49e98992',
    service_name='triangule-api-serverless',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='6.2.2',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'triangule-api-serverless-dev-api', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('wsgi_handler.handler')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
